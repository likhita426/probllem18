/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//program to find the largest digit in a number//
#include <stdio.h>
#include<math.h>
int main()
{
   int n,rem,max;
   printf("enter the value of n:");
   scanf("%d",&n);
   while(n!=0)
   {
       rem=n%10;
   if(max<rem)
   {
       max=rem;
      
   }
    n=n/10;
    
   }
  printf("%d",max);
   }
 

